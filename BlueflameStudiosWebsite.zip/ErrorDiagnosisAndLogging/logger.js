while (Error) {
  console.log("ERROR.errortype"+Error+".Reason:"+EvalError(ErrorEvent))
}
if(Error) {
  console.log("error:"+Error+EvalError(ErrorEvent))
}
//gets sent to the js folder at processingArea