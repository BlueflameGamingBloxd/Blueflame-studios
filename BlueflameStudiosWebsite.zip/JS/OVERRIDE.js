function nextFunction(value = null) {
  if (value === null) {
    value.set(a, 10)
    console.log("Null value received");
    return;
  }
}