function colorizeText(text, color) {
  return `<span style="color:${color}">${text}</span>`;
}
let myText = "This is some blue text.";
let blueText = colorizeText(myText, "blue");
document.getElementById("myElementId").innerHTML = blueText;
//unfinished ¯\_(ツ)_/¯