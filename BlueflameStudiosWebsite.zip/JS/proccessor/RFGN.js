const RFGN = {
  commutiveFunction: true,
  limitNetwork: limitNetworks,
  exampleTest: forUsers(true)
}