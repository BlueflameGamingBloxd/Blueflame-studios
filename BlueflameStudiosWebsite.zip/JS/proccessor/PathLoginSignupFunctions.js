// ===== SIGNUP SYSTEM =====

// Database simulation
const accountsDatabase = [];

// Account creation function
function createAccount(userEmail, password, refundPeriodDays = 30) {
  if (!userEmail || !password) {
    console.error("Email and password are required");
    return null;
  }
  
  // Check if email already exists
  if (accountsDatabase.some(acc => acc.email === userEmail)) {
    console.error("Email already registered");
    return null;
  }
  
  const accountCreationDate = new Date();
  const refundExpiryDate = new Date(accountCreationDate);
  refundExpiryDate.setDate(refundExpiryDate.getDate() + refundPeriodDays);
  
  const newAccount = {
    id: generateAccountId(),
    email: userEmail,
    password: hashPassword(password), // In real app hash this properly
    createdAt: accountCreationDate,
    refundExpiry: refundExpiryDate,
    refundPeriodDays: refundPeriodDays,
    hasRefundExpired: false,
    refundExpiryNotified: false,
    isActive: true
  };
  
  accountsDatabase.push(newAccount);
  console.log(`Account created for: ${userEmail}`);
  console.log(`Refund expires on: ${refundExpiryDate.toDateString()}`);
  
  // make new refund expiry check
  scheduleRefundCheck(newAccount);
  
  return newAccount;
}

// Generate account ID
function generateAccountId() {
  return 'acc_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

//  password hash sim
function hashPassword(password) {
  return btoa(password); // In real app, use bcrypt or other idk
}

//refund expiry system lol:

function checkRefundExpiry(account) {
  const currentTime = new Date();
  
  if (currentTime > account.refundExpiry && !account.hasRefundExpired) {
    console.log(`Refund period ended for: ${account.email}`);
    sendRefundExpiryEmail(account.email, account);
    
    account.hasRefundExpired = true;
    account.refundExpiryNotified = true;
    
    return true;
  }
  
  return false;
}

function sendRefundExpiryEmail(userEmail, account) {
  const emailData = {
    to: userEmail,
    subject: "Your Refund Period Has Ended",
    body: `Dear Customer,

Your ${account.refundPeriodDays}-day refund period ended on ${account.refundExpiry.toDateString()}.
Payments are now final.

Account ID: ${account.id}
Created: ${account.createdAt.toDateString()}

Contact support if you have questions.

Best regards,
Account Team`
  };
  
  console.log(` Sending email to: ${userEmail}`);
  console.log(`Subject: ${emailData.subject}`);
  
  // In real situ it integrate with email service
  // Example: await emailService.send(emailData);
  
  return emailData;
}

// Schedule refund check for acc
function scheduleRefundCheck(account) {
  const timeUntilExpiry = account.refundExpiry - new Date();
  
  if (timeUntilExpiry > 0) {
    setTimeout(() => {
      if (checkRefundExpiry(account)) {
        console.log(` Refund expiry processed for ${account.email}`);
      }
    }, timeUntilExpiry);
    
    console.log(` Refund check scheduled for ${account.email} in ${Math.ceil(timeUntilExpiry / (1000 * 60 * 60 * 24))} days`);
  } else {
    // Already expired
    checkRefundExpiry(account);
  }
}

// ===== BULK CHECK FUNCTION =====

function checkAllAccountsRefundExpiry() {
  console.log("Checking all accounts for refund expiry...");
  
  const expiredAccounts = [];
  
  accountsDatabase.forEach(account => {
    if (account.isActive && !account.hasRefundExpired) {
      if (checkRefundExpiry(account)) {
        expiredAccounts.push(account.email);
      }
    }
  });
  
  if (expiredAccounts.length > 0) {
    console.log(` Processed ${expiredAccounts.length} expired accounts`);
  } else {
    console.log(" No accounts have expired refunds");
  }
  
  return expiredAccounts;
}

function login(userEmail, password) {
  const account = accountsDatabase.find(acc =>
    acc.email === userEmail &&
    hashPassword(password) === acc.password &&
    acc.isActive
  );
  
  if (account) {
    console.log(`👋 Welcome back, ${userEmail}`);
    
    // Check refund status on login
    const remainingDays = Math.ceil((account.refundExpiry - new Date()) / (1000 * 60 * 60 * 24));
    
    if (remainingDays > 0) {
      console.log(` You have ${remainingDays} days remaining for refunds`);
    } else if (!account.hasRefundExpired) {
      console.log("Your refund period has ended");
      checkRefundExpiry(account);
    }
    
    return account;
  } else {
    console.error("Invalid email or password");
    return null;
  }
}

function getUserAccount(userEmail) {
  return accountsDatabase.find(acc => acc.email === userEmail);
}

function updateAccountEmail(oldEmail, newEmail) {
  const account = getUserAccount(oldEmail);
  if (account) {
    account.email = newEmail;
    console.log(`Email updated from ${oldEmail} to ${newEmail}`);
    return true;
  }
  return false;
}

function deactivateAccount(userEmail) {
  const account = getUserAccount(userEmail);
  if (account) {
    account.isActive = false;
    console.log(`Account deactivated: ${userEmail}`);
    return true;
  }
  return false;
}

// ===== SIMULATION =====

function runDemo() {
  console.log(" Starting signup system demo...\n");
  
  // Create some accounts
  const account1 = createAccount("alice@example.com", "password123", 7); // 7-day refund
  const account2 = createAccount("bob@example.com", "securepass", 30); // 30-day refund
  
  console.log("\n--- Database Status ---");
  console.log(`Total accounts: ${accountsDatabase.length}`);
  
  console.log("\n--- Login Test ---");
  login("alice@example.com", "password123");
  
  console.log("\n--- Manual Refund Check ---");
  checkAllAccountsRefundExpiry();
  
  console.log("\n--- Account Lookup ---");
  const aliceAccount = getUserAccount("alice@example.com");
  if (aliceAccount) {
    console.log(`Found account: ${aliceAccount.email}`);
    console.log(`Refund expiry: ${aliceAccount.refundExpiry.toDateString()}`);
  }
}

// ===== QUICK SIGNUP FUNCTION =====

// Simple one-liner for your original request
function quickSignup(userEmail) {
  const account = createAccount(userEmail, "temporaryPassword", 30);
  if (account) {
    console.log(`Account created! Check console for refund expiry date.`);
    return account;
  }
  return null;
}

// ===== EXPORT FOR USE =====

// To use this system:
// 1. Create an account: createAccount("user@example.com", "password", 30)
// 2. Check expiry: checkRefundExpiry(account)
// 3. Or run bulk check: checkAllAccountsRefundExpiry()

// Example usage:
// const myAccount = createAccount("test@example.com", "mypassword");
// if (new Date() > myAccount.refundExpiry) {
//     sendRefundExpiryEmail(myAccount.email, myAccount);
// }

// Run demo (comment out if not needed)
// runDemo();